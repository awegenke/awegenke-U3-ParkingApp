public class CheckOut {

    public int endtime;

    public int getEndtime() {
        return endtime;
    }
    public void setEndtime(int newEndtime) {
        this.endtime = newEndtime;
    }

    public static void Checkingout(){
        return

         ;
    }
}
