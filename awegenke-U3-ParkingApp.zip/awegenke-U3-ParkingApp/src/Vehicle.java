public class Vehicle {
    private int ticketid;

    public int getTicketid() {
        return ticketid;
    }

    public void setTicketid(int newTicketid) {
        this.ticketid = newTicketid;
    }

}



    /*
    should hold all the vehicles that enter and keep track with the int num and then repeat these every time maybe should
    add a for loop not sure
*/




