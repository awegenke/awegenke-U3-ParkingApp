public class CheckIn {

    public int starttime;

    public int getStarttime() {
        return starttime;
    }

    public void setStarttime(int newStarttime) {
        this.starttime = newStarttime;
    }



    }

